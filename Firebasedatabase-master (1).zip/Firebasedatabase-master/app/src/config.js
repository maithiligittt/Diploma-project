export const firebaseConfig = {
  apiKey: 'AIzaSyCE3Qpq8U4UtI1A6h6x67Ep9WKfe6m0ywQ',
  authDomain: 'dabewala-7640a.firebaseapp.com',
  databaseURL: 'https://dabewala-7640a-default-rtdb.firebaseio.com',
  projectId: 'dabewala-7640a',
  storageBucket: 'dabewala-7640a.appspot.com',
  messagingSenderId: '678556845092',
  appId: '1:678556845092:web:6457e250f7061b984c84b1',
  measurementId: 'G-4NN55R9M0R',
};
