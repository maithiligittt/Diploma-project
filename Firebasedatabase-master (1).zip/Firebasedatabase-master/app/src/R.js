import {colors} from '../res/colors'
import {fonts} from '../res/fonts'
import {images} from '../res/images'
import {strings} from '../res/strings'
import {dimensions} from '../res/dimensions.js'
const R = {colors,fonts,images,strings,dimensions};
export default R;