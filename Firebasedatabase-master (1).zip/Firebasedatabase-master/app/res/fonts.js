export const fonts = {
  //define fonts here
};