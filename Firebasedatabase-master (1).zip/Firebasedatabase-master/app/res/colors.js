export const colors = {
  //define colors here
  maroon: '#800000',
  white: '#fff',
  lightPink: 'rgba(255,221,250,0.79)',
  black: '#000',
  gray: '#808080',
};
