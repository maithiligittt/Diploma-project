export const strings = {
  //define strings here
};