export const images = {
  //define images here

  arrow: require('../res/images/arrow.png'),
  splash_logo: require('../res/images/Logo1.png'),
  backgroundImage: require('../res/images/backgroundImage.jpg'),
  menu: require('../res/images/Menu.png'),
  man: require('../res/images/man.jpg'),
  checked: require('../res/images/checked.png'),
  tiffinBox: require('../res/images/tiffinBox.png'),
  x: require('../res/images/x.jpg'),
  clock: require('../res/images/clock.png'),
  pin: require('../res/images/pin.png'),
  box: require('../res/images/box.jpg'),
  dMan: require('../res/images/dMan.jpg'),
  user: require('../res/images/user.png'),
  noOrder: require('../res/images/noOrder.jpg'),
};
